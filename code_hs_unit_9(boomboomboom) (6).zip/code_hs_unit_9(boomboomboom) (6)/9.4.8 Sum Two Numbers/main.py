x=11
a=12
def twoargum(x,a):
    return(x+a)
twoargum(11,12)
