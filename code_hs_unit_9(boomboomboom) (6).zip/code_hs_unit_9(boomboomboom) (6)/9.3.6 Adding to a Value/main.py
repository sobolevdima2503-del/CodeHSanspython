x=int(input("number"))
# rwrwdr
num1 = 10
print(num1+x)
# Your code here...
def func():
    x=int(input("number"))
    # rwrwdr
    num1 = 10
    print(num1+x)
func()
