
def my_function(x,a):
    print(x*a)
my_function(1,2)
