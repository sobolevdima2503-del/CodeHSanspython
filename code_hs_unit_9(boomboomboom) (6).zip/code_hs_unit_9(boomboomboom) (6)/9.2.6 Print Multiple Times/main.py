def print_multiple_times(x,a):
    str(a)
    print(x*a)
print_multiple_times(3,"hi")
