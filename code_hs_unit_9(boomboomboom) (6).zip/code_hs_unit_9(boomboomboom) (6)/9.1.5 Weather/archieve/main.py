a=input("What is the weather? (sunny, rainy, snowy)")
b="rainy"
c="snowy"
d="sunny"
def rain():
    print("On a rainy day, galoshes are appropriate footwear.")
def snow():
    print("on snowy day I wear boots")
def sun():
    print("I wear sandals")
if a==b:
    rain()
if a==c:
    snow()
if a==d:
    sun()
else:
    print("it isn't valid")