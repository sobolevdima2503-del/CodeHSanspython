a = int(input("What is the first number?:"))
b = int(input("What is the second number?:"))
oper = input("Choose an operation (add, subtract, multiply):")

def add():
    sum = a + b
    print (str(a) + " + " + str(b) + " = " + str(sum))
def subtract():
    sum = a - b
    print (str(a) + " - " + str(b) + " = " + str(sum))
def multiply():
    sum = a * b
    print (str(a) + " * " + str(b) + " = " + str(sum))

if oper == "add":
    add()
elif oper == "subtract":
    subtract()
elif oper == "multiply":
    multiply()
